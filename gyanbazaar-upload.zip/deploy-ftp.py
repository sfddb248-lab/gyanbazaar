#!/usr/bin/env python3
"""
GyanBazaar - Automatic FTP Deployment
"""

import ftplib
import os
import sys
from pathlib import Path

# Configuration
FTP_HOST = "ftpupload.net"
FTP_USER = "if0_40371517"
FTP_PASS = "Nitin@9917"
LOCAL_DIR = "deploy-package"
REMOTE_DIR = "/htdocs"

def upload_directory(ftp, local_path, remote_path):
    """Recursively upload directory to FTP"""
    try:
        ftp.cwd(remote_path)
    except:
        # Directory doesn't exist, create it
        try:
            ftp.mkd(remote_path)
            ftp.cwd(remote_path)
        except:
            pass
    
    for item in os.listdir(local_path):
        local_item = os.path.join(local_path, item)
        remote_item = f"{remote_path}/{item}"
        
        if os.path.isfile(local_item):
            # Upload file
            print(f"Uploading: {item}")
            try:
                with open(local_item, 'rb') as file:
                    ftp.storbinary(f'STOR {item}', file)
                print(f"  ✓ Done")
            except Exception as e:
                print(f"  ✗ Failed: {e}")
        
        elif os.path.isdir(local_item):
            # Create directory and recurse
            print(f"Creating directory: {item}")
            try:
                ftp.mkd(item)
            except:
                pass  # Directory might already exist
            
            # Save current directory
            current_dir = ftp.pwd()
            
            # Recurse into subdirectory
            upload_directory(ftp, local_item, remote_item)
            
            # Return to parent directory
            ftp.cwd(current_dir)

def main():
    print("=" * 50)
    print("  GyanBazaar - FTP Deployment")
    print("=" * 50)
    print()
    
    if not os.path.exists(LOCAL_DIR):
        print(f"Error: {LOCAL_DIR} directory not found!")
        sys.exit(1)
    
    print(f"Connecting to {FTP_HOST}...")
    
    try:
        # Connect to FTP
        ftp = ftplib.FTP(FTP_HOST, timeout=30)
        ftp.login(FTP_USER, FTP_PASS)
        
        print("✓ Connected successfully!")
        print()
        
        # Change to remote directory
        try:
            ftp.cwd(REMOTE_DIR)
        except:
            print(f"Creating {REMOTE_DIR}...")
            ftp.mkd(REMOTE_DIR)
            ftp.cwd(REMOTE_DIR)
        
        print(f"Uploading files from {LOCAL_DIR} to {REMOTE_DIR}...")
        print()
        
        # Upload all files
        upload_directory(ftp, LOCAL_DIR, REMOTE_DIR)
        
        print()
        print("=" * 50)
        print("  Upload Complete!")
        print("=" * 50)
        print()
        print("Your site is now live at:")
        print("https://gyanbazaar.infinityfreeapp.com")
        print()
        print("Admin Panel:")
        print("https://gyanbazaar.infinityfreeapp.com/admin")
        print()
        
        ftp.quit()
        
    except ftplib.error_perm as e:
        print(f"✗ FTP Error: {e}")
        print()
        print("Common issues:")
        print("- Wrong username or password")
        print("- Account not activated yet (wait 10 minutes)")
        sys.exit(1)
    
    except Exception as e:
        print(f"✗ Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
