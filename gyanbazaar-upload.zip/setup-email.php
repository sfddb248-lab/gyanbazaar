<?php
// Redirect to auto-configure page
header('Location: auto-configure-email.php');
exit;
?>
