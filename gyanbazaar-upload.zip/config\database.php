<?php
define('DB_HOST', 'sql301.infinityfreeapp.com');
define('DB_USER', 'if0_40371517');
define('DB_PASS', 'Nitin@9917');
define('DB_NAME', 'if0_40371517_gyanbazaar');

// Create connection
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
