<?php
define('SITE_URL', 'https://gyanbazaar.infinityfreeapp.com');
define('SITE_NAME', 'GyanBazaar');
define('ADMIN_EMAIL', 'admin@gyanbazaar.com');
?>
